import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Plan } from '../models/plan.model';
import { API_URL } from './api.service';

@Injectable({
  providedIn: 'root'
})
export class PlanService {
  constructor(private http: HttpClient) {}

  getPlans(): Observable<Plan[]> {
    return this.http.get<Plan[]>(`${API_URL}/plans`);
  }

  getPlanById(planId: number): Observable<Plan[]> {
    return this.http.get<Plan[]>(`${API_URL}/plans?planId=${planId}`);
  }
  
}
