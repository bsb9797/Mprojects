export interface Booking {
  id?: number;   // <-- optional for JSON server
  name: string;
  city: string;
  phone: string;
  email: string;
  age: number;
  planId: number;
  planName: string;
  validity: number;
  paymentMode: string;
  cardNumber: string;
  premiumAmt: number;
  paymentFreq: string;
}
