import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PlanService } from '../../core/services/plan.service';
import { Plan } from '../../core/models/plan.model';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-plans',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './plans.html',
  styleUrls: ['./plans.css']
})
export class Plans {
  plans$!: Observable<Plan[]>;  // Observable directly

  selectedPlan: Plan | null = null;

  constructor(private planService: PlanService, private router: Router) {
    this.plans$ = this.planService.getPlans(); // assign observable once
  }

  viewDetails(plan: Plan): void {
    this.selectedPlan = plan;
  }

  buyPlan(plan: Plan): void {
    this.router.navigate(['/buy'], { queryParams: { planId: plan.planId } });
  }
}
