import { Component, OnInit, NgZone } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { BookingService } from '../../core/services/booking.service';
import { PlanService } from '../../core/services/plan.service';
import { Booking } from '../../core/models/booking.model';
import { Plan } from '../../core/models/plan.model';

@Component({
  selector: 'app-buy',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './buy.html',
  styleUrls: ['./buy.css']
})
export class Buy implements OnInit {

  plan!: Plan;
  planId!: number;

  booking: Booking = {
    name: '',
    city: '',
    phone: '',
    email: '',
    age: 0,
    planId: 0,
    planName: '',
    validity: 0,
    paymentMode: '',
    cardNumber: '',
    premiumAmt: 0,
    paymentFreq: ''
  };

  success = false;
  submitting = false;
  errorMessage = '';

  constructor(
    private route: ActivatedRoute,
    private bookingService: BookingService,
    private planService: PlanService,
    private zone: NgZone
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.planId = +params['planId'];

      this.planService.getPlanById(this.planId).subscribe({
        next: (res) => {
          this.plan = res[0]; // get the first match
          this.booking.planId = this.plan.planId;
          this.booking.planName = this.plan.planName;
          this.booking.validity = this.plan.validity;
          this.calculatePremium();
        },
        error: (err) => {
          console.error('Failed to load plan', err);
          this.errorMessage = 'Failed to load selected plan.';
        }
      });
      
      
    });
  }

  calculatePremium(): void {
    if (!this.booking.age || this.booking.age <= 0) {
      this.booking.premiumAmt = 0;
      return;
    }

    let premium = this.plan.baseAmt;

    if (this.booking.age > 30) {
      premium += 2000;
    }

    this.booking.premiumAmt = premium;
  }

  isFormValid(): boolean {
    return (
      this.booking.name.trim() !== '' &&
      this.booking.city.trim() !== '' &&
      /^\d{10}$/.test(this.booking.phone) &&
      /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(this.booking.email) &&
      this.booking.age > 0 &&
      this.booking.paymentMode !== '' &&
      (this.booking.paymentMode.toLowerCase().includes('card') ? this.booking.cardNumber.trim() !== '' : true) &&
      this.booking.paymentFreq !== '' &&
      this.booking.premiumAmt > 0
    );
  }

  submit(): void {
    if (!this.isFormValid() || this.submitting) return;
  
    this.submitting = true;
    this.errorMessage = '';
  
    this.bookingService.createBooking(this.booking).subscribe({
      next: (res) => {
        // Ensure Angular detects the change
        this.zone.run(() => {
          console.log('Booking response:', res);
          this.success = true;       // show success message
          this.submitting = false;   // stop "Processing..."
        });
      },
      error: (err) => {
        this.zone.run(() => {
          console.error('Booking failed', err);
          this.success = false;
          this.errorMessage = 'Failed to complete booking.';
          this.submitting = false;
        });
      }
    });
  }
  
  }

