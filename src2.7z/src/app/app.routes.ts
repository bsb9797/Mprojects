import { Routes } from '@angular/router';
import { Home } from './pages/home/home';
import { About } from './pages/about/about';
import { Plans } from './pages/plans/plans';
import { Buy } from './pages/buy/buy';
 
export const routes: Routes = [
  { path: '', component: Home },          // Home
  { path: 'about', component: About },    // About Us
  { path: 'plans', component: Plans },    // View Plans
  { path: 'buy', component: Buy },        // Buy Plan
  { path: '**', redirectTo: '' }                   // Fallback
];