export interface Plan {
  planId: number;            // Unique ID of the plan
  planName: string;          // Name of the insurance plan
  description: string;       // Detailed description of the plan
  baseAmt: number;           // Base premium amount
  validity: number;          // Plan validity in days
  features?: string[];       // Optional: List of features or benefits
}
