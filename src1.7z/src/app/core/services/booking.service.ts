import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Booking } from '../models/booking.model';
import { API_ENDPOINTS } from './api.service';

@Injectable({
  providedIn: 'root'
})
export class BookingService {

  constructor(private http: HttpClient) {}

  /**
   * Create a new insurance booking
   * @param booking - Booking details provided by the user
   */
  createBooking(booking: Booking): Observable<Booking> {
    return this.http.post<Booking>(API_ENDPOINTS.BOOKING, booking);
  }

  /**
   * Get all bookings (optional: for admin or testing purposes)
   */
  getBookings(): Observable<Booking[]> {
    return this.http.get<Booking[]>(API_ENDPOINTS.BOOKING);
  }
}
