import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { Plan } from '../models/plan.model';
import { API_ENDPOINTS } from './api.service';

@Injectable({
  providedIn: 'root'
})
export class PlanService {

  constructor(private http: HttpClient) {}

  /**
   * Get all insurance plans
   */
  getPlans(): Observable<Plan[]> {
    return this.http.get<Plan[]>(API_ENDPOINTS.PLANS);
  }

  /**
   * Get a single plan by its planId
   * @param planId - ID of the plan to fetch
   */
  getPlanById(planId: number): Observable<Plan> {
    return this.http.get<Plan[]>(API_ENDPOINTS.PLAN_BY_ID(planId))
      .pipe(
        map(plans => plans[0]) // Extract the first (and only) plan
      );
  }
}
