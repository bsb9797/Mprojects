// api.service.ts
export const API_URL = 'http://localhost:3333';

export const API_ENDPOINTS = {
  PLANS: `${API_URL}/plans`,        // GET: Fetch all plans
  BOOKING: `${API_URL}/bookings`,   // POST: Create a booking
  PLAN_BY_ID: (planId: number) => `${API_URL}/plans?planId=${planId}` // GET: Fetch plan by ID
};
