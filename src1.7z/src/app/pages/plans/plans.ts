import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PlanService } from '../../core/services/plan.service';
import { Plan } from '../../core/models/plan.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-plans',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './plans.html',
  styleUrls: ['./plans.css']
})
export class Plans implements OnInit {

  plans: Plan[] = [];               // All available plans
  selectedPlan: Plan | null = null; // Plan currently viewed in detail
  loading: boolean = false;         // Loading state
  errorMessage: string = '';        // Error message if API fails

  constructor(
    private planService: PlanService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadPlans();
  }

  /**
   * Load all insurance plans from the API
   */
  loadPlans(): void {
    this.loading = true;
    this.planService.getPlans().subscribe({
      next: (data) => {
        this.plans = data;
        this.loading = false;
      },
      error: (err) => {
        console.error('Error loading plans', err);
        this.errorMessage = 'Failed to load insurance plans. Please try again later.';
        this.loading = false;
      }
    });
  }

  /**
   * View details of a selected plan
   * @param plan - Selected plan
   */
  viewDetails(plan: Plan): void {
    this.selectedPlan = plan;
  }

  /**
   * Navigate to Buy Page with the selected plan
   * @param plan - Selected plan to purchase
   */
  buyPlan(plan: Plan): void {
    this.router.navigate(['/buy'], {
      queryParams: {
        planId: plan.planId
      }
    });
  }
}
