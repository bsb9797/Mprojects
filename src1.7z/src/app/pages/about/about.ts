import { Component } from '@angular/core';

@Component({
  selector: 'app-about',
  standalone: true,
  imports: [],
  templateUrl: './about.html',
  styleUrls: ['./about.css'],
})
export class About {
  appName: string = 'Raindrops Insurance Service';
  developer: string = 'Developed by: Your Name';

  guide: string = `Welcome to the Raindrops Insurance Service web app. 
You can view insurance plans, calculate premiums based on your details, 
and purchase your preferred plan seamlessly.`;

  keyFeatures: string[] = [
    'View all available insurance plans',
    'Calculate premium based on age, earnings, and health conditions',
    'Book and pay for insurance plans online',
    'Get instant confirmation of your subscription'
  ];

  contactDetails: { phone: string; email: string; address: string } = {
    phone: '+91 98765 43210',
    email: 'support@raindropsinsurance.com',
    address: '123, Insurance Street, Chennai, Tamil Nadu, India'
  };
}
