import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { BookingService } from '../../core/services/booking.service';
import { PlanService } from '../../core/services/plan.service';
import { Booking } from '../../core/models/booking.model';
import { Plan } from '../../core/models/plan.model';

@Component({
  selector: 'app-buy',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './buy.html',
  styleUrls: ['./buy.css']
})
export class Buy implements OnInit {

  // Selected plan
  plan!: Plan;
  planId!: number;

  // Booking details entered by the user
  booking: Booking = {
    name: '',
    city: '',
    phone: '',
    email: '',
    age: 0,
    planId: 0,
    planName: '',
    validity: 0,
    paymentMode: '',
    cardNumber: '',
    premiumAmt: 0,
    paymentFreq: ''
  };

  success: boolean = false;
  submitting: boolean = false;
  errorMessage: string = '';

  constructor(
    private route: ActivatedRoute,
    private bookingService: BookingService,
    private planService: PlanService
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.planId = +params['planId'];

      // Fetch plan by ID
      this.planService.getPlanById(this.planId).subscribe({
        next: (res) => {
          this.plan = res;
          this.booking.planId = this.plan.planId;
          this.booking.planName = this.plan.planName;
          this.booking.validity = this.plan.validity;
        },
        error: (err) => {
          console.error('Failed to load plan', err);
          this.errorMessage = 'Failed to load selected plan. Please try again later.';
        }
      });
    });
  }

  /**
   * Calculate premium based on age and base amount
   */
  calculatePremium(): void {
    if (!this.booking.age || this.booking.age <= 0) {
      this.booking.premiumAmt = 0;
      return;
    }

    let premium = this.plan.baseAmt;

    // Example business logic: add extra for age > 30
    if (this.booking.age > 30) {
      premium += 2000;
    }

    this.booking.premiumAmt = premium;
  }

  /**
   * Check if form is valid before submission
   */
  isFormValid(): boolean {
    return (
      this.booking.name.trim() !== '' &&
      this.booking.city.trim() !== '' &&
      /^\d{10}$/.test(this.booking.phone) &&
      /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(this.booking.email) &&
      this.booking.age > 0 &&
      this.booking.paymentMode !== '' &&
      (this.booking.paymentMode.includes('card') ? this.booking.cardNumber.trim() !== '' : true) &&
      this.booking.paymentFreq !== '' &&
      this.booking.premiumAmt > 0
    );
  }

  /**
   * Submit booking to the server
   */
  submit(): void {
    if (!this.isFormValid() || this.submitting) return;

    this.submitting = true;
    this.errorMessage = '';

    this.bookingService.createBooking(this.booking).subscribe({
      next: () => {
        this.success = true;
        this.submitting = false;
      },
      error: (err) => {
        console.error('Booking failed', err);
        this.success = false;
        this.errorMessage = 'Failed to complete booking. Please try again.';
        this.submitting = false;
      }
    });
  }
}
