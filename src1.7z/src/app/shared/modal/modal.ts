import { Component } from '@angular/core';
import { RouterLink,RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-modal',
  standalone : true,
  imports: [RouterLink,RouterLinkActive],
  templateUrl: './modal.html',
  styleUrl: './modal.css',
})
export class Modal {

}
